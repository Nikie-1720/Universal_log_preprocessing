"""ULPF Collector Agent - offline/local telemetry collector.

The agent is deliberately lightweight and dependency-free:
- tails configured log files/directories on Linux/Unix
- optionally reads systemd journal through journalctl
- optionally reads Windows Event Log through PowerShell/Get-WinEvent
- persists collected records in a local SQLite spool before delivery
- sends batches to the local ULPF gateway over HTTP(S)
- registers and heartbeats with the gateway
No cloud service is used or required.
"""
from __future__ import annotations
import argparse, fnmatch, hashlib, json, os, platform, queue, sqlite3, ssl, subprocess, sys, threading, time, urllib.error, urllib.request, uuid
from pathlib import Path

from discovery import discover

ROOT=Path(__file__).resolve().parent
DEFAULT_CONFIG=ROOT/"agent.yaml"
DEFAULT_STATE=ROOT/"state"
CONFIG=os.environ.get("ULPF_AGENT_CONFIG", str(DEFAULT_CONFIG))

def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def load_config(path):
    # JSON is accepted even with .yaml extension to keep the agent zero-dependency.
    try:
        text=Path(path).read_text(encoding="utf-8")
        try: return json.loads(text)
        except json.JSONDecodeError:
            # Tiny YAML subset: key: scalar, lists indented by "-".
            out={}; current=None
            for raw in text.splitlines():
                s=raw.strip()
                if not s or s.startswith("#"): continue
                if s.startswith("- ") and current:
                    out.setdefault(current,[]).append(s[2:].strip().strip('"\''))
                elif ":" in s:
                    k,v=s.split(":",1); k=k.strip(); v=v.strip()
                    if not v: current=k; out[k]=[]
                    else:
                        current=None
                        if v.lower() in ("true","false"): v=v.lower()=="true"
                        elif v.isdigit(): v=int(v)
                        else: v=v.strip('"\'')
                        out[k]=v
            return out
    except OSError as e: raise SystemExit(f"Cannot read agent config: {e}")

class Spool:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(path,check_same_thread=False)
        self.lock=threading.Lock()
        self.db.execute("CREATE TABLE IF NOT EXISTS queue (id INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT NOT NULL, created REAL NOT NULL, fingerprint TEXT UNIQUE)")
        self.max_spool = int(os.environ.get("ULPF_AGENT_MAX_SPOOL", str(100000)))
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.commit()
    def put(self, payload):
        with self.lock:
            blob=json.dumps(payload,ensure_ascii=False,separators=(",",":"))
            identity=payload.get("offset")
            if identity is None:
                try: identity=(json.loads(str(payload.get("raw",""))).get("Id") or json.loads(str(payload.get("raw",""))).get("RecordId"))
                except Exception: identity=None
            fp=hashlib.sha256((str(payload.get("agent_id",""))+"|"+str(payload.get("address",""))+"|"+str(identity if identity is not None else payload.get("raw",""))).encode()).hexdigest()
            count = self.db.execute("SELECT COUNT(*) FROM queue").fetchone()[0]
            if count >= self.max_spool:
                self.db.execute("DELETE FROM queue WHERE id IN (SELECT id FROM queue ORDER BY id LIMIT ?)", (max(1, count - self.max_spool + 1),))
            self.db.execute("INSERT OR IGNORE INTO queue(payload,created,fingerprint) VALUES(?,?,?)",(blob,time.time(),fp))
            self.db.commit()
    def batch(self,n):
        with self.lock:
            rows=self.db.execute("SELECT id,payload FROM queue ORDER BY id LIMIT ?",(n,)).fetchall()
        return [(i,json.loads(p)) for i,p in rows]
    def ack(self, ids):
        if not ids:return
        with self.lock:
            self.db.executemany("DELETE FROM queue WHERE id=?",[(i,) for i in ids]); self.db.commit()
    def size(self):
        with self.lock:return self.db.execute("SELECT COUNT(*) FROM queue").fetchone()[0]
    def close(self): self.db.close()
    def integrity_check(self):
        with self.lock:
            return self.db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"

class Agent:
    def __init__(self,cfg):
        self.cfg=cfg
        self.id_file=Path(cfg.get("agent_id_file",DEFAULT_STATE/"agent-id"))
        self.id_file.parent.mkdir(parents=True,exist_ok=True)
        if self.id_file.exists(): self.agent_id=self.id_file.read_text().strip()
        else:
            self.agent_id="ULPF-"+str(uuid.uuid4())
            self.id_file.write_text(self.agent_id,encoding="utf-8")
        self.name=cfg.get("name") or platform.node() or self.agent_id
        self.gateway=str(cfg.get("gateway","http://127.0.0.1:5173")).rstrip("/")
        self.token=os.environ.get("ULPF_AGENT_TOKEN",str(cfg.get("token","")))
        self.tls=cfg.get("tls") or {}
        self.ssl_context=self._ssl_context()
        self.spool=Spool(cfg.get("spool",str(DEFAULT_STATE/"spool.db")))
        self.stop=threading.Event()
        self.discovery = discover(cfg.get("files", []))
        self.offsets={}
        self.offset_file=Path(cfg.get("offset_file",str(DEFAULT_STATE/"offsets.json")))
        try:self.offsets=json.loads(self.offset_file.read_text())
        except Exception:pass
    def _ssl_context(self):
        """Build an optional TLS/mTLS context without weakening verification."""
        if not self.gateway.lower().startswith("https://"):
            return None
        ctx=ssl.create_default_context(cafile=self.tls.get("ca_file") or None)
        if self.tls.get("cert_file") and self.tls.get("key_file"):
            ctx.load_cert_chain(self.tls["cert_file"], self.tls["key_file"])
        if self.tls.get("insecure_skip_verify") is True:
            # Deliberately opt-in only for isolated development deployments.
            ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
        return ctx
    def headers(self):
        h={"Content-Type":"application/json","X-ULPF-Agent-ID":self.agent_id}
        if self.token:h["Authorization"]="Bearer "+self.token
        return h
    def post(self,path,payload,timeout=8):
        data=json.dumps(payload,ensure_ascii=False).encode()
        req=urllib.request.Request(self.gateway+path,data=data,headers=self.headers(),method="POST")
        with urllib.request.urlopen(req,timeout=timeout,context=self.ssl_context) as r:return json.loads(r.read() or b"{}")
    def register(self):
        try:
            return self.post("/api/agents/register",{
                "agent_id":self.agent_id,"name":self.name,"hostname":platform.node(),
                "os":platform.platform(),"agent_version":"1.0.0",
                "sources":self.discovery.get("sources",[]),"capabilities":self.discovery.get("capabilities",[]),
                "discovery":self.discovery,
            })
        except Exception as e:
            print("register offline:",e,file=sys.stderr); return None
    def heartbeat(self):
        try:return self.post("/api/agents/heartbeat",{"agent_id":self.agent_id,"hostname":platform.node(),
            "os":platform.system(),"queue_size":self.spool.size(),"time":now_iso()})
        except Exception:return None
    def enqueue(self,raw,source,address,offset=None):
        if not raw.strip():return
        payload={"raw":raw,"source_type":source,"address":address,"transport":"agent",
                 "agent_id":self.agent_id,"agent_name":self.name,"received_time":now_iso()}
        if offset is not None:payload["offset"]=offset
        self.spool.put(payload)
    def save_offsets(self):
        tmp=self.offset_file.with_suffix(".tmp"); tmp.write_text(json.dumps(self.offsets),encoding="utf-8"); tmp.replace(self.offset_file)
    def tail_file(self,path):
        try:size=os.path.getsize(path)
        except OSError:return
        key=os.path.abspath(path); off=int(self.offsets.get(key,0))
        if size<off:off=0
        try:
            with open(path,"r",encoding="utf-8",errors="replace") as f:
                f.seek(off)
                for line in f:
                    self.enqueue(line.rstrip("\r\n"),"file",path,f.tell())
                self.offsets[key]=f.tell()
        except OSError:return
    def discover_files(self):
        result=[]
        for item in self.cfg.get("files",[]) or []:
            p=Path(os.path.expandvars(str(item)))
            if p.is_file():result.append(str(p))
        for d in self.cfg.get("directories",[]) or []:
            p=Path(os.path.expandvars(str(d.get("path",d) if isinstance(d,dict) else d)))
            pattern=(d.get("pattern","*.log") if isinstance(d,dict) else "*.log")
            if p.exists():
                for x in p.rglob("*"):
                    if x.is_file() and fnmatch.fnmatch(x.name,pattern):result.append(str(x))
        return list(dict.fromkeys(result))
    def file_loop(self):
        while not self.stop.is_set():
            for p in self.discover_files():self.tail_file(p)
            self.save_offsets(); time.sleep(float(self.cfg.get("poll_interval",1.0)))
    def journal_loop(self):
        if platform.system()=="Windows" or not self.cfg.get("journald",False):return
        cursor_key="__journald_cursor__"
        cursor=str(self.offsets.get(cursor_key,"") or "")
        cmd=["journalctl","-f","-n","0","-o","json","--show-cursor"]
        if cursor:
            cmd.extend(["--after-cursor",cursor])
        try:
            proc=subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                bufsize=1
            )
        except (OSError,FileNotFoundError):
            return
        while not self.stop.is_set():
            line=proc.stdout.readline() if proc.stdout else ""
            if not line:
                time.sleep(.2)
                continue
            line=line.rstrip("\r\n")
            if not line:
                continue
            if line.startswith("-- cursor:"):
                self.offsets[cursor_key]=line.split(":",1)[1].strip()
                self.save_offsets()
                continue
            try:
                obj=json.loads(line)
            except json.JSONDecodeError:
                continue
            raw=obj.get("MESSAGE")
            if raw is None:
                raw=line
            self.enqueue(str(raw),"journald","systemd-journal")
        try:
            proc.terminate()
        except OSError:
            pass
    def windows_loop(self):
        if platform.system()!="Windows" or not self.cfg.get("windows_eventlog",False):return
        channels=self.cfg.get("windows_channels",["System","Application","Security"])
        while not self.stop.is_set():
            # Pull a small recent window repeatedly; EventRecordID deduplication prevents repeats.
            for ch in channels:
                ps=("Get-WinEvent -LogName '"+str(ch).replace("'","''")+"' -MaxEvents 20 | "
                    "ForEach-Object { $_ | ConvertTo-Json -Compress -Depth 5 }")
                try:
                    out=subprocess.check_output(["powershell","-NoProfile","-NonInteractive","-Command",ps],
                                                stderr=subprocess.DEVNULL,text=True,timeout=15)
                    for line in out.splitlines():
                        if line.strip():self.enqueue(line,"windows-eventlog",ch)
                except Exception:pass
            time.sleep(float(self.cfg.get("windows_poll_interval",5)))
    def send_loop(self):
        interval=float(self.cfg.get("send_interval",.5)); batch=int(self.cfg.get("batch_size",100)); backoff=interval
        while not self.stop.is_set():
            rows=self.spool.batch(batch)
            if rows:
                ids=[i for i,_ in rows]
                try:
                    batch_payload=[]
                    for row_id, item in rows:
                        copy=dict(item); copy["_spool_id"]=row_id
                        batch_payload.append(copy)
                    r=self.post("/api/ingest-agent",{"agent_id":self.agent_id,"events":batch_payload},timeout=15)
                    ack_ids=r.get("ack_ids")
                    if isinstance(ack_ids,list):
                        self.spool.ack([int(i) for i in ack_ids if str(i).isdigit()])
                    elif r.get("accepted",0)>=len(rows):self.spool.ack(ids)
                    backoff=interval
                except Exception:
                    self.stop.wait(backoff)
                    backoff=min(30.0, max(interval, backoff*2))
            else:self.stop.wait(interval)
    def heartbeat_loop(self):
        while not self.stop.is_set():
            self.heartbeat(); self.stop.wait(float(self.cfg.get("heartbeat_interval",10)))
    def diagnostics(self):
        """Print a local-only discovery/capability report and exit.

        No gateway/network access is performed by this command.
        """
        print(json.dumps(self.discovery, indent=2, ensure_ascii=False))

    def run(self):
        self.register()
        threads=[threading.Thread(target=self.file_loop,daemon=True),
                 threading.Thread(target=self.journal_loop,daemon=True),
                 threading.Thread(target=self.windows_loop,daemon=True),
                 threading.Thread(target=self.send_loop,daemon=True),
                 threading.Thread(target=self.heartbeat_loop,daemon=True)]
        for t in threads:t.start()
        try:
            while True:time.sleep(1)
        except KeyboardInterrupt:self.stop.set()
        finally:self.save_offsets();self.spool.close()

def main():
    parser = argparse.ArgumentParser(description="ULPF offline collector agent")
    parser.add_argument("--config", default=CONFIG)
    parser.add_argument("command", nargs="?", choices=["run", "discover"], default="run")
    args = parser.parse_args()
    cfg = load_config(args.config)
    agent = Agent(cfg)
    if args.command == "discover":
        agent.diagnostics()
        agent.spool.close()
        return 0
    agent.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
